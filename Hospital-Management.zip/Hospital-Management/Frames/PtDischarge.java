package Frames;
import Classes.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class PtDischarge extends JFrame  implements  ActionListener  {
	
	JLabel nameLabel,pdLabel,imgLabel, srchLabel;
	JTextField srchTF;
	
	JButton disBtn, bckBtn,  srchBtn;
	Font font1,font2,font4,font5;
	Color color1;
	ImageIcon img,icon;
	JPanel panel;
	public PtDischarge(){
		super("AIUB-CARE");
		this.setSize(900,600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		icon = new ImageIcon("images/icon.jpg");
		this.setIconImage(icon.getImage());
		
		font1 = new Font("Biome",Font.BOLD, 30);
		font2 = new Font("Biome",Font.BOLD, 18);
		font4 = new Font("Bookman Old Style", Font.BOLD, 15);
		font5 = new Font("ADLaM Display",Font.ITALIC, 16);

		color1= new Color(143,207,225);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		nameLabel = new JLabel("AIUB-CARE");
		nameLabel.setBounds(320,7,400,100);
		nameLabel.setFont(font1);
		nameLabel.setForeground(Color.WHITE);
		panel.add(nameLabel);
		
		pdLabel = new JLabel("Discharge Patient");
		pdLabel.setBounds(100,100,180,30);
		pdLabel.setFont(font2);
		pdLabel.setForeground(Color.WHITE);
		panel.add(pdLabel);
		
		srchLabel = new JLabel("Search by Name: ");
		srchLabel.setBounds(100,170,170,20);
		srchLabel.setFont(font4);
		srchLabel.setForeground(Color.WHITE);
		panel.add(srchLabel);; 

		srchBtn = new JButton("Search");
		srchBtn.setBounds(400,170,60,20);
		srchBtn.setFont(font5);
		srchBtn.setBorder(null);
		
		srchBtn.setBackground(Color.GRAY);
		srchBtn.setForeground(Color.RED);
		srchBtn.addActionListener(this);
		panel.add(srchBtn);

		srchTF = new JTextField();
		srchTF.setBounds(233,172,145,20);
		panel.add(srchTF); 
			
		disBtn = new JButton("Discharge");
		disBtn.setBounds(100,220,100,30);
		disBtn.setBackground(Color.BLACK);
		disBtn.setForeground(Color.WHITE);
		disBtn.addActionListener(this);
		panel.add(disBtn);
		
		
		bckBtn = new JButton("Back");
		bckBtn.setBounds(220,220,100,30);
		bckBtn.setBackground(Color.BLACK);
		bckBtn.setForeground(Color.WHITE);
		bckBtn.addActionListener(this);
		panel.add(bckBtn);
		
		img = new ImageIcon("images/Discharge2.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,900,600);
		panel.add(imgLabel);
		
		panel.setBackground(color1);
		this.add(panel);
		
	}
	public void actionPerformed(ActionEvent ae){
		String command = ae.getActionCommand();
		
		if (ae.getSource() == bckBtn){
			Menu me = new Menu();
			me.setVisible(true);
			this.setVisible(false);	
				
		} 
		else if (ae.getSource() == disBtn){
			JOptionPane.showMessageDialog(this , "Please enter search button !");
		}
		else if(srchBtn.getText().equals(command)){
			String name = srchTF.getText ();
			PList pl = new PList();
			if(!name.isEmpty()){
					int index = pl.searchPatient(name);
				if(index == -1){
					JOptionPane.showMessageDialog(this , "Patient does not exist !");
				}
				else {
					Patient p = pl.getPatient(index);
					Discharge ptd = new Discharge(p, pl);
					ptd.setVisible(true);
					this.setVisible(false);
				}
			}
			else{
				JOptionPane.showMessageDialog(this , "Please enter a name !");
			}
			
		}
	
   }
}