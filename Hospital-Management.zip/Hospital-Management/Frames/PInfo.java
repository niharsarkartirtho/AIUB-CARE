package Frames;
import Classes.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;

public class PInfo extends JFrame implements ActionListener {

    JLabel userLabel, imgLabel;
    JButton back;
    Color color1, color2;
    Font font1, font2;
    ImageIcon img, icon;
    JPanel panel;
    JTable table;
    DefaultTableModel model;

    public PInfo() {
        super("AIUB-CARE");
        this.setSize(900, 600);
        icon = new ImageIcon("images/icon.jpg");
		this.setIconImage(icon.getImage());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        color1 = new Color(143, 207, 225);
		color2 = new Color(182, 224, 232);

        font1 = new Font("Biome", Font.BOLD, 30);
        font2 = new Font("Biome", Font.BOLD, 18);

        panel = new JPanel();
        panel.setLayout(null);

        userLabel = new JLabel("AIUB-CARE");
        userLabel.setBounds(320, 20, 400, 100);
        userLabel.setFont(font1);
        setForeground(Color.BLACK);
        panel.add(userLabel);

        userLabel = new JLabel("Patient List ");
        userLabel.setBounds(360, 70, 400, 50);
        userLabel.setFont(font2);
        userLabel.setForeground(Color.BLACK);
        panel.add(userLabel);

		model = new DefaultTableModel();
        table = new JTable(model);
		table.setBackground(color2);
		table.setFont(new Font("Times New Roman", Font.BOLD, 16));
		
		model.addColumn("Patient ID");
        model.addColumn("Name");
        model.addColumn("Gender");
		model.addColumn("Appointed Dr.");
		model.addColumn("Room No.");
		model.addColumn("diagnosis");

        PList pli = new PList();
        for(int i = 0; i < pli.patientList.length; i++) {
			Patient pl = pli.patientList[i];
            if (pl != null) {
                model.addRow(new Object[]{pl.getId(), pl.getName(), pl.getGender(), pl.getAppointedDoctor(), pl.getRoom(), pl.getDiagnosis()});
            }
        }
        
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(70, 150, 750, 270);
        panel.add(scrollPane);

        back = new JButton("BACK");
        back.setBounds(620, 470, 100, 40);
        back.setBackground(Color.RED);
        back.setForeground(Color.WHITE);
        back.setOpaque(true);
        back.addActionListener(this);
        panel.add(back);

        img= new ImageIcon("images/hospi.jpg");
		
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,900,600);
		panel.add(imgLabel);

        panel.setBackground(color1);
        this.add(panel);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == back) {
            Menu me = new Menu();
            me.setVisible(true);
            this.setVisible(false);
        }
    }
}