package Frames;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.*;

public class Login extends JFrame implements ActionListener {
    JLabel userLabel, passLabel, bgLabel;
    JTextField UTField;
    JPasswordField UPField;
    JButton loginBtn, registerBtn;
    Font font20 = new Font("Cambria", Font.PLAIN, 20);

    public Login() {
        super("Login Page");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(600, 450);
        this.setLocationRelativeTo(null);
        this.setLayout(null);

        // Icon Image
        ImageIcon logoIcon = new ImageIcon("images/icon.jpg");
        this.setIconImage(logoIcon.getImage());

        // Background Image
        ImageIcon backgroundImage = new ImageIcon("images/Discharge.jpg");
        Image resizedBackground = backgroundImage.getImage().getScaledInstance(600, 450, Image.SCALE_SMOOTH);
        backgroundImage = new ImageIcon(resizedBackground);
        bgLabel = new JLabel(backgroundImage);
        bgLabel.setBounds(0, 0, 600, 450);
        bgLabel.setLayout(null);

        // UserName 
        userLabel = new JLabel("User Name");
        userLabel.setBounds(200, 50, 200, 30);
        userLabel.setFont(font20);
        bgLabel.add(userLabel);

        UTField = new JTextField();
        UTField.setBounds(200, 90, 200, 30);
        UTField.setFont(font20);
        bgLabel.add(UTField);

        // Password 
        passLabel = new JLabel("Password");
        passLabel.setBounds(200, 130, 200, 30);
        passLabel.setFont(font20);
        bgLabel.add(passLabel);

        UPField = new JPasswordField();
        UPField.setBounds(200, 170, 200, 30);
        UPField.setFont(font20);
        UPField.setEchoChar('*');
        bgLabel.add(UPField);

        // Login Button
        loginBtn = new JButton("Login");
        loginBtn.setBounds(200, 210, 200, 30);
        loginBtn.setFont(font20);
        loginBtn.setBackground(Color.BLACK);
        loginBtn.setForeground(Color.WHITE);
        loginBtn.addActionListener(this);
        bgLabel.add(loginBtn);

        // Register Button
        registerBtn = new JButton("Register");
        registerBtn.setBounds(200, 250, 200, 30);
        registerBtn.setFont(font20);
        registerBtn.setBackground(Color.BLACK);
        registerBtn.setForeground(Color.WHITE);
        registerBtn.addActionListener(this);
        bgLabel.add(registerBtn);

        this.add(bgLabel);
        this.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e){
		if (e.getSource() == loginBtn){
            String username = UTField.getText().trim();
            String password = new String(UPField.getPassword());

            try (BufferedReader reader = new BufferedReader(new FileReader("Files/Password.txt"))) {
                String line;
                boolean isValid = false;

                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(":");
                    if (parts[0].equals(username) && parts[1].equals(password)) {
                        isValid = true;
                        break;
                    }
                }

                if (isValid) {
                    JOptionPane.showMessageDialog(Login.this, "Login successful!");
                    dispose();
                   Menu main= new Menu();
                   main.setVisible(true);
                }
                else {
                    JOptionPane.showMessageDialog(Login.this, "Incorrect User Name or incorrect password!");
                }
            } 
            catch (IOException ex) {
                JOptionPane.showMessageDialog(Login.this, "USER NOT FOUND");
            }
		}
        else if (e.getSource() == registerBtn){
            RegisterPage reg = new RegisterPage();
            dispose();
        }
    }
}
