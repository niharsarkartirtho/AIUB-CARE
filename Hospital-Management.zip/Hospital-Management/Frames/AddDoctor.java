package Frames;
import Classes.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class AddDoctor extends JFrame implements ActionListener {
    JLabel idField, idLabel, userLabel, programLabel, imgLabel;
    JTextField userTF;
    JButton add, backBtn;
    JComboBox dept;
    Color color1;
    Font font1, font2;
    ImageIcon img,icon;
    JPanel panel;
    RegDoctorList rdl;

    public AddDoctor() {
        super("AIUB-CARE");
        this.setSize(900, 600);
        icon = new ImageIcon("images/icon.jpg");
        this.setIconImage(icon.getImage());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.rdl = new RegDoctorList(); 

        color1 = new Color(143, 207, 225);

        font1 = new Font("Georgia", Font.BOLD, 30);
        font2 = new Font("Biome", Font.BOLD, 18);

        panel = new JPanel();
        panel.setLayout(null);

        userLabel = new JLabel("AIUB-CARE");
        userLabel.setBounds(320, 10, 400, 100);
        userLabel.setFont(font1);
        userLabel.setForeground(Color.WHITE);
        panel.add(userLabel);

        userLabel = new JLabel("Doctor Registration");
        userLabel.setBounds(75, 80, 450, 30);
        userLabel.setForeground(Color.WHITE);
        userLabel.setFont(font2);
        panel.add(userLabel);

        idLabel = new JLabel("Doctor ID: ");
        idLabel.setBounds(75, 91, 100, 100);
        idLabel.setForeground(Color.WHITE);
        panel.add(idLabel);

        idField = new JLabel("DID" + (2001 + rdl.doctorCount));
        idField.setBounds(170, 130, 100, 20);
        idField.setForeground(Color.WHITE);
        panel.add(idField);

        userLabel = new JLabel("Doctor Name: ");
        userLabel.setBounds(75, 120, 100, 100);
        userLabel.setForeground(Color.WHITE);   
        panel.add(userLabel);

        userTF = new JTextField();
        userTF.setBounds(170, 162, 200, 20);
        panel.add(userTF);

        programLabel = new JLabel("Department:");
        programLabel.setBounds(75, 150, 100, 100);
        programLabel.setForeground(Color.WHITE);
        panel.add(programLabel);

        String items[] = {"MEDICINE", "CARDIOLOGY", "NEUROSURGERY", "ONCOLOGIST", "ORTHOPEDICS", "SURGERY", "PSYCHIATRY", "ANESTHESIOLOGY"};
        dept = new JComboBox(items);
        dept.setBounds(170, 192, 200, 20);
        panel.add(dept);

        add = new JButton("Register");
        add.setBounds(500, 470, 100, 40);
        add.setBackground(Color.GRAY);
        add.setForeground(Color.WHITE);
        add.setOpaque(true);
        add.addActionListener(this);
        panel.add(add);

        backBtn = new JButton("BACK");
        backBtn.setBounds(620, 470, 100, 40);
        backBtn.setBackground(Color.RED);
        backBtn.setForeground(Color.WHITE);
        backBtn.setOpaque(true);
        backBtn.addActionListener(this);
        panel.add(backBtn);

        img = new ImageIcon("images/Discharge2.jpg");
        imgLabel = new JLabel(img);
        imgLabel.setBounds(0,0,900,600);
        panel.add(imgLabel);

        panel.setBackground(color1);
        this.add(panel);
    }

    public void actionPerformed(ActionEvent ae) {
        String command = ae.getActionCommand();
        if (backBtn.getText().equals(command)) {
            Menu main = new Menu();
            main.setVisible(true);
            this.setVisible(false);
        } else if (add.getText().equals(command)) {
            String id = idField.getText();
            String name = userTF.getText();
            String department = dept.getSelectedItem().toString();

            if (!id.isEmpty() && !name.isEmpty() && !department.isEmpty()) {
                Doctor d = new Doctor(id, name, department);
                rdl.addDoctor(d);
                JOptionPane.showMessageDialog(this, "Doctor Added!");
                this.setVisible(false);
				Menu main = new Menu();
                main.setVisible(true);
			
            } else {
                JOptionPane.showMessageDialog(this, "You can not leave any field empty!");
            }
        }
    }
}