package Frames;
import Classes.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Discharge extends JFrame  implements  ActionListener  {
	
	JLabel nameLabel,pdLabel,ptnLabel,roomLabel,adLabel,billLabel,imgLabel;
	JTextField roomTF,addTF,billTF,ptTF;
	
	JButton disBtn, bckBtn;
	Font font1,font2,font3;
	Color color1;
	ImageIcon img,icon;
	JPanel panel;
	Patient p;
	PList  pl;
	public Discharge(Patient p,PList pl){
		super("AIUB-CARE");
		this.setSize(900,600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		icon = new ImageIcon("images/icon.jpg");
		this.setIconImage(icon.getImage());
		this.p = p;
		this.pl = pl;
	
		
		font1 = new Font("Biome",Font.BOLD, 30);
		font2 = new Font("Biome",Font.BOLD, 18);
		font3 = new Font("Biome",Font.BOLD, 14);

		color1= new Color(143,207,225);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		nameLabel = new JLabel("AIUB-CARE");
		nameLabel.setBounds(320,7,400,100);
		nameLabel.setFont(font1);
		nameLabel.setForeground(Color.WHITE);
		panel.add(nameLabel);
		
		pdLabel = new JLabel("Discharge Patient");
		pdLabel.setBounds(100,100,180,30);
		pdLabel.setFont(font2);
		pdLabel.setForeground(Color.WHITE);
		panel.add(pdLabel);

		ptnLabel = new JLabel("Patient Name : ");
		ptnLabel.setBounds(100,155,120,20);
		ptnLabel.setFont(font3);
		ptnLabel.setForeground(Color.WHITE);
		panel.add(ptnLabel);
		
		
		ptTF = new JTextField(p.getName());
		ptTF.setBounds(225,155,150,20);
		panel.add(ptTF);
		
		roomLabel = new JLabel("Room Number : ");
		roomLabel.setBounds(100,190,120,20);
		roomLabel.setFont(font3);
		roomLabel.setForeground(Color.WHITE);
		panel.add(roomLabel);
		
		
		roomTF = new JTextField(p.getRoom());
		roomTF.setBounds(225,190,150,20);
		panel.add(roomTF);
		
		adLabel = new JLabel("Released by : ");
		adLabel.setBounds(100,225,120,20);
		adLabel.setFont(font3);
		adLabel.setForeground(Color.WHITE);
		panel.add(adLabel);
		
		
		addTF = new JTextField(p.getAppointedDoctor());
		addTF.setBounds(225,225,150,20);
		panel.add(addTF); 
		
		
		billLabel = new JLabel("Bill : ");
		billLabel.setBounds(100,260,120,20);
		billLabel.setFont(font3);
		billLabel.setForeground(Color.WHITE);
		panel.add(billLabel);
		
		
		billTF = new JTextField(p.getDeposit());
		billTF.setBounds(225,260,150,20);
		panel.add(billTF);	
		
		disBtn = new JButton("Discharge");
		disBtn.setBounds(100,330,100,30);
		disBtn.setBackground(Color.BLACK);
		disBtn.setForeground(Color.WHITE);
		disBtn.addActionListener(this);
		panel.add(disBtn);
		
		
		bckBtn = new JButton("Back");
		bckBtn.setBounds(220,330,100,30);
		bckBtn.setBackground(Color.BLACK);
		bckBtn.setForeground(Color.WHITE);
		bckBtn.addActionListener(this);
		panel.add(bckBtn);
			
		img = new ImageIcon("images/Discharge2.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,900,600);
		panel.add(imgLabel);
		
		panel.setBackground(color1);
		this.add(panel);
		
	}
	 @Override
	public void actionPerformed(ActionEvent ae){
		String command = ae.getActionCommand();
		if(disBtn.getText().equals(command)){
			int dialog = JOptionPane.YES_NO_OPTION;
			int result = JOptionPane.showConfirmDialog(this, "Are you sure you want to Discharge?", "Discharge Patient?", dialog);
			if(result == 0){
				pl.deletePatient(p);
			
				Menu me = new Menu();
				me.setVisible(true);
				this.setVisible(false);
			}
		}	
		else if (ae.getSource() == bckBtn){
			
			Menu me = new Menu();
			me.setVisible(true);
			this.setVisible(false);
		} 
   }

}