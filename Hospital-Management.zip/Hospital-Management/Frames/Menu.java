package Frames;

import Classes.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Menu extends JFrame implements ActionListener, MouseListener{
	JLabel nameLabel, titleLabel, imgLabel;
	JButton npBtn, dpBtn, pInfoBtn, pUpBtn, drInfoBtn, lgtBtn, addocBtn,deldocBtn;
	ImageIcon img, icon;
	Font font1, font2;
	JPanel panel;
	
	public Menu(){
		super("AIUB-CARE");
		this.setSize(900,600);
		icon = new ImageIcon("images/icon.jpg");
		this.setIconImage(icon.getImage());
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		
		font1 = new Font("Biome",Font.BOLD, 30);
		font2 = new Font("Cascadia Code SemiBold",Font.BOLD, 20);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		nameLabel = new JLabel("AIUB-CARE");
		nameLabel.setBounds(340,20,400,100);
		nameLabel.setFont(font1);
		panel.add(nameLabel);

		titleLabel = new JLabel("Health is Wealth");
		titleLabel.setBounds(372,420,400,200);
		titleLabel.setFont(font2);
		titleLabel.setForeground(Color.BLACK);
		panel.add(titleLabel);
		
		npBtn = new JButton("Add Patient");
		npBtn.setBounds(240,120,175,40);
		npBtn.setBackground(Color.CYAN);
		npBtn.setForeground(Color.BLACK);
		npBtn.addMouseListener(this);
		npBtn.addActionListener(this);
		panel.add(npBtn);
		
		dpBtn = new JButton("Discharge Patient");
		dpBtn.setBounds(240,220,175,40);
		dpBtn.setBackground(Color.CYAN);
		dpBtn.setForeground(Color.BLACK);
		dpBtn.addMouseListener(this);
		dpBtn.addActionListener(this);
		panel.add(dpBtn);
		
		pInfoBtn = new JButton("Patient Info");
		pInfoBtn.setBounds(240,320,175,40);
		pInfoBtn.setBackground(Color.CYAN);
		pInfoBtn.setForeground(Color.BLACK);
		pInfoBtn.addMouseListener(this);
		pInfoBtn.addActionListener(this);
		panel.add(pInfoBtn);
		
		pUpBtn = new JButton("Upadate Patient");
		pUpBtn.setBounds(240,420,175,40);
		pUpBtn.setBackground(Color.CYAN);
		pUpBtn.setForeground(Color.BLACK);
		pUpBtn.addMouseListener(this);
		pUpBtn.addActionListener(this);
		panel.add(pUpBtn);
		
		drInfoBtn = new JButton("Doctor Info");
		drInfoBtn.setBounds(450,320,175,40);
		drInfoBtn.setBackground(Color.CYAN);
		drInfoBtn.setForeground(Color.BLACK);
		drInfoBtn.addMouseListener(this);
		drInfoBtn.addActionListener(this);
		panel.add(drInfoBtn);
		
		lgtBtn = new JButton("LOGOUT");
		lgtBtn.setBounds(450,420,175,40);
		lgtBtn.setForeground(Color.WHITE);
		lgtBtn.setBackground(Color.RED);
		lgtBtn.addMouseListener(this);
		lgtBtn.addActionListener(this);
		panel.add(lgtBtn);

		addocBtn = new JButton("Add Doctor");
		addocBtn.setBounds(450,120,175,40);
		addocBtn.setForeground(Color.BLACK);
		addocBtn.setBackground(Color.CYAN);
		addocBtn.addActionListener(this);
		addocBtn.addMouseListener(this);
		panel.add(addocBtn);
		
		deldocBtn = new JButton("Release Doctor");
		deldocBtn.setBounds(450,220,175,40);
		deldocBtn.setForeground(Color.BLACK);
		deldocBtn.setBackground(Color.CYAN);
		deldocBtn.addActionListener(this);
		deldocBtn.addMouseListener(this);
		panel.add(deldocBtn);
		
		img = new ImageIcon("images/hospi.jpg");
		
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,900,600);
		
		panel.add(imgLabel);
		this.add(panel);
	}

	
    public void mouseClicked(MouseEvent me) {}
    public void mousePressed(MouseEvent me) {}
    public void mouseReleased(MouseEvent me) {}

    public void mouseEntered(MouseEvent me) {
        JButton source = (JButton) me.getSource();
        source.setBackground(Color.GREEN);
        source.setForeground(Color.BLACK);
    }

    public void mouseExited(MouseEvent me) {
        JButton source = (JButton) me.getSource();
        source.setBackground(Color.CYAN);
        source.setForeground(Color.BLACK);
    }
	
	public void actionPerformed(ActionEvent ae){
		if (ae.getSource() == npBtn) {
			PList pl = new PList();
			AddPatient ap = new AddPatient(pl);
			ap.setVisible(true);
			this.setVisible(false);
        } else if (ae.getSource() == dpBtn) {
			PtDischarge pd = new PtDischarge();
			pd.setVisible(true);
			this.setVisible(false);
        } else if (ae.getSource() == pUpBtn) {
			UpPatient up = new UpPatient();
			up.setVisible(true);
			this.setVisible(false);
		}else if (ae.getSource() == pInfoBtn) {
			PInfo pi = new PInfo();
			pi.setVisible(true);
			this.setVisible(false);
		}
		else if (ae.getSource() == drInfoBtn) {
			DoctorList dl = new DoctorList();
			dl.setVisible(true);
			this.setVisible(false);
		}
		else if (ae.getSource() == addocBtn) {
			AddDoctor add = new AddDoctor();
			add.setVisible(true);
			this.setVisible(false);
		}
		else if (ae.getSource() == deldocBtn) {
			DischargeDoc  del = new DischargeDoc();
			del.setVisible(true);
			this.setVisible(false);
		}
		else if (ae.getSource() == lgtBtn) {
			int dialog = JOptionPane.YES_NO_OPTION;
			int result = JOptionPane.showConfirmDialog(this, "Are you sure to Logout?", "Logout", dialog);
			if(result == 0){
				JOptionPane.showMessageDialog(this, "Logout Successful!");
				Login li = new Login();
				li.setVisible(true);
				this.setVisible(false);
			} 
			else{
				
			}		
		}
		
	}
		
} 