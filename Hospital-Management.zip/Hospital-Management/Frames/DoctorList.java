package Frames;
import Classes.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class DoctorList extends JFrame implements ActionListener {
    JButton back;
    JLabel userLabel;
    JTable table;
    DefaultTableModel model;
    JScrollPane scrollPane;
    JPanel panel;
    RegDoctorList regDoctorList;
    Color color1;
    Font font1, font2;
    ImageIcon img,icon;
    JLabel imgLabel;

    public DoctorList() {
        super("AIUB-CARE");
        this.setSize(900, 600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        icon = new ImageIcon("images/icon.jpg");
        this.setIconImage(icon.getImage());
        this.setLocationRelativeTo(null);
        this.regDoctorList = new RegDoctorList(); 

        color1 = new Color(143, 207, 225);
        font1 = new Font("Biome", Font.BOLD, 30);
        font2 = new Font("Biome", Font.BOLD, 18);

        panel = new JPanel();
        panel.setLayout(null);

        userLabel = new JLabel("AIUB-CARE");
        userLabel.setBounds(320, 20, 400, 100);
        userLabel.setFont(font1);
        setForeground(Color.BLACK);
        panel.add(userLabel);

        userLabel = new JLabel("Doctor List ");
        userLabel.setBounds(360, 70, 400, 50);
        userLabel.setFont(font2);
        userLabel.setForeground(Color.BLACK);
        panel.add(userLabel);

        String[] columnNames = {"Doctor ID", "Doctor Name", "Department"};
        model = new DefaultTableModel(columnNames, 0);
        table = new JTable(model);

        for (int i = 0; i < regDoctorList.doctorCount; i++) {
            Doctor doctor = regDoctorList.doctorList[i];
            if (doctor != null) {
                model.addRow(new Object[]{doctor.getId(), "Dr. " + doctor.getName(), doctor.getDepartment()});
            }
        }

        scrollPane = new JScrollPane(table);
        scrollPane.setBounds(70, 150, 750, 270);
        panel.add(scrollPane);

        back = new JButton("BACK");
        back.setBounds(620, 470, 100, 40);
        back.setBackground(Color.RED);
        back.setForeground(Color.WHITE);
        back.setOpaque(true);
        back.addActionListener(this);
        panel.add(back);

        img = new ImageIcon("images/hospi.jpg");
        imgLabel = new JLabel(img);
        imgLabel.setBounds(0, 0, 900, 600);
        panel.add(imgLabel);

        panel.setBackground(color1);
        this.add(panel);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == back) {
            Menu me = new Menu();
            me.setVisible(true);
            this.setVisible(false);
        }
    }
}
