package Frames;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.*;

public class RegisterPage extends JFrame{
    JLabel userLabel, passLabel, conPassLabel, bgLabel;
    JTextField UTField;
    JPasswordField userPassField, userConPassField;
    JButton backBtn, registerBtn;
    Font font20 = new Font("Cambria", Font.BOLD, 20);
    Font font10 = new Font("Cambria", Font.BOLD, 10);
    public RegisterPage() {
        super("Register Page");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(600, 450);
        this.setLocationRelativeTo(null);
        this.setLayout(null);

        // Icon Image
        ImageIcon logoIcon = new ImageIcon("images/icon.jpg");
        this.setIconImage(logoIcon.getImage());

        // Background Image
        ImageIcon backgroundImage = new ImageIcon("images/Discharge.jpg");
        Image resizedBackground = backgroundImage.getImage().getScaledInstance(600, 450, Image.SCALE_SMOOTH);
        backgroundImage = new ImageIcon(resizedBackground);
        bgLabel = new JLabel(backgroundImage);
        bgLabel.setBounds(0, 0, 600, 450);
        bgLabel.setLayout(null); // Allow adding components

        // User Name Label and Field
        userLabel = new JLabel("User Name");
        userLabel.setBounds(180, 50, 200, 30);
        userLabel.setFont(font20);
		//userLabel.setForeground(Color.YELLOW);
        bgLabel.add(userLabel);

        UTField = new JTextField();
        UTField.setBounds(180, 90, 200, 30);
        UTField.setFont(font20);
        bgLabel.add(UTField);

        // Password Label and Field
        passLabel = new JLabel("Password");
        passLabel.setBounds(180, 130, 200, 30);
        passLabel.setFont(font20);
        //passLabel.setForeground(Color.YELLOW);
	    bgLabel.add(passLabel);

        userPassField = new JPasswordField();
        userPassField.setBounds(180, 170, 200, 30);
        userPassField.setFont(font20);
        userPassField.setEchoChar('*');
        bgLabel.add(userPassField);

        // Confirm Password Label and Field
        conPassLabel = new JLabel("Confirm Password");
        conPassLabel.setBounds(180, 210, 200, 30);
        conPassLabel.setFont(font20);
        bgLabel.add(conPassLabel);

        userConPassField = new JPasswordField();
        userConPassField.setBounds(180, 250, 200, 30);
        userConPassField.setFont(font20);
        userConPassField.setEchoChar('*');
        bgLabel.add(userConPassField);

        // Register Button
        registerBtn = new JButton("Register");
        registerBtn.setBounds(180, 290, 200, 30);
        registerBtn.setBackground(Color.BLUE);
		registerBtn.setForeground(Color.WHITE);
		registerBtn.setFont(font20);
        registerBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = UTField.getText().trim();
                String password = new String(userPassField.getPassword());
                String confirmPassword = new String(userConPassField.getPassword());

                if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                    JOptionPane.showMessageDialog(RegisterPage.this, "All fields are required!");
                    return;
                }
                if (!password.equals(confirmPassword)) {
                    JOptionPane.showMessageDialog(RegisterPage.this, "Passwords do not match!");
                    return;
                }
                try (BufferedWriter writer = new BufferedWriter(new FileWriter("Files/Password.txt", true))) {
                    writer.write(username + ":" + password);
                    writer.newLine();
                    JOptionPane.showMessageDialog(RegisterPage.this, "Registration successful!");
                    dispose();
                    Login log= new Login();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(RegisterPage.this, "Error saving user data!");
                }
            }
        });
        bgLabel.add(registerBtn);

        backBtn = new JButton();
        backBtn.setBounds(30, 350, 80, 40);
        backBtn.setFont(font10);
        ImageIcon backIcon = new ImageIcon("images/back.jpg");
        Image resizedBackIcon = backIcon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
        backBtn.setIcon(new ImageIcon(resizedBackIcon));
        backBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                Login log= new Login();
            }
        });
        bgLabel.add(backBtn);

        this.add(bgLabel);
        this.setVisible(true);
    }
}
