package Classes;

import java.io.*;
import java.util.Scanner;

public class RegDoctorList {
    public Doctor doctorList[] = new Doctor[1000];
    public static int doctorCount = 0;

    public RegDoctorList() {
        try {
            File file = new File("Files/DoctorList.txt");
            Scanner sc = new Scanner(file);
            while (sc.hasNext()) {
                String line1 = sc.nextLine();  // id
                String line2 = sc.nextLine();  // name
                String line3 = sc.nextLine();  // department
                String line4 = sc.nextLine();  // extra newline

                Doctor d = new Doctor(line1, line2, line3);
                doctorList[doctorCount] = d;
                doctorCount++;
            }
            sc.close();
        } catch (Exception ex) {
            System.out.println("File not found.");
            return;
        }
    }
    public void addDoctor(Doctor d) {
        if (doctorCount >= doctorList.length) {
            System.out.println("Doctor list is full. Cannot add more doctors.");
            return;
        }
        doctorList[doctorCount] = d;
        doctorCount++;
        System.out.println("Doctor added to array: " + d.getName());
        String DrDetails = d.getId() + "\n" + d.getName() + "\n" + d.getDepartment() + "\n" + "\n";
        try (FileWriter fw = new FileWriter("Files/DoctorList.txt", true)) {
            fw.write(DrDetails);
            fw.flush();
            System.out.println("Doctor details written to file: " + d.getName());
        } catch (IOException ex) {
            System.out.println("Error writing to file: " + ex.getMessage());
        }
    }
    public int doctorExists(String name) {
        int index = -1;
        for (int i = 0; i < doctorCount; i++) {
            if (doctorList[i] != null && doctorList[i].getName().equals(name)) {
                index = i;
                break;
            }
        }
        return index;
    }
	public void deleteDoctor(Doctor d){
		for(int i = 0; i<doctorCount; i++){
			if(doctorList[i] == d){
				for(int j = i; j<doctorCount-1; j++){
					doctorList[j] = doctorList[j+1];
				}
				doctorCount--;
				doctorList[doctorCount]=null;
				updateDoctorFile();
				break;
			}
		}
	}
	private void updateDoctorFile() {
        try {
            FileWriter fw = new FileWriter("Files/DoctorList.txt");
            for (int i = 0; i < doctorCount; i++) {
                Doctor d = doctorList[i];
                if (d != null) {
                    String DrDetails = d.getId() + "\n" + d.getName() + "\n" + d.getDepartment() + "\n" + "\n";
                    fw.write(DrDetails);
                }
            }
            fw.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
	

    public Doctor getDoctor(int index) {
        return doctorList[index];
    }

    public String[] getDoctorNames() {
        String doctorNames[] = new String[doctorCount];
        for (int i = 0; i < doctorCount; i++) {
            if (doctorNames != null && doctorList[i] != null) {
                doctorNames[i] = "Dr. " + doctorList[i].getName();
            }
        }
        return doctorNames;
    }
}
