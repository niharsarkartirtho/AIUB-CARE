package Classes;

public class Doctor extends Person {
    private String department;

    public Doctor(String id, String name, String department) {
        super(id, name, "default1", "default2");
        this.department = department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDepartment() {
        return department;
    }
}